"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import PrescriptionChecklist, {
  type PrescriptionChecklistHandle,
} from "../components/PrescriptionChecklist";
import type {
  ChecklistSection,
  SelectedPrescription,
} from "../components/PrescriptionChecklist";
import { applySelectionsToSections } from "../components/checklistModel";
import SideCart, { type SideCartHandle } from "../components/SideCart";
import type { MiniCartAssignmentOps } from "@/app/modules/miniCart/assignmentOps";
import styles from "./cart.module.css";
import type { CartTemplate } from "@/app/(directory)/components/cartTemplatesStorage";
import DirectoryPageHeader from "@/app/(directory)/components/DirectoryPageHeader";
import { fetchEncryptedJson } from "@/app/lib/encryptedPayload/client";
import {
  CART_VISIT_STORAGE_KEY,
  createEventId,
  sendOpeningEvent,
  type CartVisit,
} from "@/app/modules/clinicalRecommendationOpening/client";
import { collectMedicationQuery } from "../components/medications/medicationQuery";
import { medsCatalogSession } from "../components/medications/medsCatalogSession";
import {
  cartStorage,
  getCartSync,
  getRecommendationStorageKey,
  getStoredCartRecommendation,
  normalizeStoredSelectionItems,
  subscribeCartSync,
  writeStoredSelections,
  type StoredCartAssignmentBucket,
  type StoredCartRecommendation,
} from "@/app/(directory)/shared/cart";
import {
  EMPTY_ASSIGNMENT_SNAPSHOT,
  type ChecklistAssignmentSnapshot,
} from "@/app/(directory)/components/medications/assignmentSnapshot";
import MiniCartHost, {
  type MiniCartHostHandle,
} from "@/app/modules/miniCart/MiniCartHost";
import { categoryIdToMiniCartTabId } from "@/app/modules/miniCart/adapters/fromDirectoryCart";
import { useDirectoryMiniCartData } from "@/app/modules/miniCart/hooks/useDirectoryMiniCartData";
import type { MiniCartDisplayMode } from "@/app/modules/miniCart/types";
import {
  prepareSelectedRecommendation,
  type RecommendationStandard,
} from "@/app/(directory)/shared/mkb";
import { COPY_CLIPBOARD_ERROR_MESSAGE } from "../components/cartClipboard";

type AppendixA3Table = {
  name: string | null;
  html: string;
  comment: string | null;
};

const snapshotFromStoredAssignments = (
  bucket: StoredCartAssignmentBucket,
): ChecklistAssignmentSnapshot => ({
  ...EMPTY_ASSIGNMENT_SNAPSHOT,
  medicationDrafts: bucket.medicationDrafts,
  medicationIntake: bucket.medicationIntake,
  commentSources: bucket.commentSources,
});

const getDiagnosisCodeFromTitle = (title: string) => {
  const trimmedTitle = title.trim();
  if (!trimmedTitle) return "";

  return trimmedTitle.split(":")[0]?.trim() ?? trimmedTitle;
};

const sameSelectionIds = (
  left: SelectedPrescription[],
  right: SelectedPrescription[],
) => {
  if (left.length !== right.length) return false;

  return left.every((item, index) => {
    const other = right[index];
    return (
      item.id === other.id &&
      item.comment === other.comment &&
      item.title === other.title
    );
  });
};

const sameBaseSectionIds = (
  left: ChecklistSection[],
  right: ChecklistSection[],
) => {
  if (left.length !== right.length) return false;

  return left.every((section, index) => {
    const other = right[index];
    if (
      !other ||
      section.id !== other.id ||
      section.categoryId !== other.categoryId ||
      section.items.length !== other.items.length
    ) {
      return false;
    }

    return section.items.every(
      (item, itemIndex) => item.id === other.items[itemIndex]?.id,
    );
  });
};

export default function CartPreviewPage() {
  const router = useRouter();
  const [selectedItems, setSelectedItems] = useState<SelectedPrescription[]>([]);
  const [uncheckItemId, setUncheckItemId] = useState<string | null>(null);
  const [clearSelectionSignal, setClearSelectionSignal] = useState(0);
  const [diagnosisTitle, setDiagnosisTitle] = useState("");
  const [diagnosisCode, setDiagnosisCode] = useState("");
  const [recommendationId, setRecommendationId] = useState("");
  const [recommendationSource, setRecommendationSource] = useState("");
  const [recommendationTitle, setRecommendationTitle] = useState("");
  /** Базовые секции КР без пользовательского checked — шаблон. */
  const [baseSections, setBaseSections] = useState<ChecklistSection[]>([]);
  const [recommendationKey, setRecommendationKey] = useState("");
  const [appliedTemplateItems, setAppliedTemplateItems] = useState<SelectedPrescription[] | null>(null);
  const [appendixA3Tables, setAppendixA3Tables] = useState<AppendixA3Table[]>([]);
  const [isAppendixA3Loading, setIsAppendixA3Loading] = useState(false);
  const [appendixA3Error, setAppendixA3Error] = useState("");
  const [isCartReady, setIsCartReady] = useState(false);
  const isRestoringStoredSelectionsRef = useRef(false);
  const syncApplyingRef = useRef(false);
  const baseSectionsRef = useRef<ChecklistSection[]>([]);
  const recommendationKeyRef = useRef("");
  const selectedItemsRef = useRef<SelectedPrescription[]>([]);
  /** Внешняя гидратация drafts в checklist без remount. */
  const [assignmentHydrateEpoch, setAssignmentHydrateEpoch] = useState(0);
  /** Снимает syncApplying после эффектов checklist (children-first). */
  const [syncReleaseNonce, setSyncReleaseNonce] = useState(0);
  const [miniCartMode, setMiniCartMode] =
    useState<MiniCartDisplayMode>("full");
  const [assignmentSnapshot, setAssignmentSnapshot] =
    useState<ChecklistAssignmentSnapshot>(EMPTY_ASSIGNMENT_SNAPSHOT);

  /** checked/comment из selections — авторитетный источник для таблицы. */
  const checklistSections = useMemo(
    () => applySelectionsToSections(baseSections, selectedItems),
    [baseSections, selectedItems],
  );
  const miniCartRef = useRef<MiniCartHostHandle>(null);
  const checklistRef = useRef<PrescriptionChecklistHandle>(null);
  const sideCartRef = useRef<SideCartHandle>(null);
  const appendixRequestIdRef = useRef(0);
  const switchRequestIdRef = useRef(0);
  const [isSwitchingRecommendation, setIsSwitchingRecommendation] =
    useState(false);

  recommendationKeyRef.current = recommendationKey;
  selectedItemsRef.current = selectedItems;

  const handleMiniCartCollapse = useCallback(() => {
    const categoryId = checklistRef.current?.getActiveCategoryId();
    const activeTabId = categoryId
      ? categoryIdToMiniCartTabId(categoryId)
      : undefined;
    void miniCartRef.current?.requestCompactFromGesture(activeTabId);
  }, []);

  const handleAssignmentSnapshotChange = useCallback(
    (snapshot: ChecklistAssignmentSnapshot) => {
      setAssignmentSnapshot(snapshot);

      const key = recommendationKeyRef.current;
      if (!key || syncApplyingRef.current) return;

      cartStorage.writeAssignments(key, {
        medicationDrafts: snapshot.medicationDrafts,
        medicationIntake: snapshot.medicationIntake,
        commentSources: snapshot.commentSources ?? {},
      });
    },
    [],
  );

  const switchingRef = useRef(false);
  switchingRef.current = isSwitchingRecommendation;

  /** Стабильные обёртки: делегируют в checklist / SideCart (единый store). */
  const miniCartAssignmentOps = useMemo<MiniCartAssignmentOps>(
    () => ({
      toggleItem: (itemId) => {
        if (switchingRef.current) return;
        checklistRef.current?.toggleItem(itemId);
      },
      setItemChecked: (itemId, checked) => {
        if (switchingRef.current) return;
        checklistRef.current?.setItemChecked(itemId, checked);
      },
      setComment: (itemId, comment) => {
        if (switchingRef.current) return;
        checklistRef.current?.setItemComment(itemId, comment);
      },
      applyMedsPick: (itemId, pick) => {
        if (switchingRef.current) return;
        checklistRef.current?.applyMedsPick(itemId, pick);
      },
      setMedicationField: (itemId, field, value, options) => {
        if (switchingRef.current) return;
        checklistRef.current?.setMedicationField(itemId, field, value, options);
      },
      selectAllRequiredDiagnostics: () => {
        if (switchingRef.current) return;
        checklistRef.current?.selectAllRequiredDiagnostics();
      },
      applyCombination: (itemId, draft) => {
        if (switchingRef.current) return;
        checklistRef.current?.applyCombination(itemId, draft);
      },
      setMedicationIntake: (itemId, intake) => {
        if (switchingRef.current) return;
        checklistRef.current?.setMedicationIntake(itemId, intake);
      },
      setMedicationInfoComment: (itemId, comment) => {
        if (switchingRef.current) return;
        checklistRef.current?.setMedicationInfoComment(itemId, comment);
      },
      resetMedicationAssignment: (itemId) => {
        if (switchingRef.current) return;
        checklistRef.current?.resetMedicationAssignment(itemId);
      },
      applyOriginalRecommendation: (itemId) => {
        if (switchingRef.current) return;
        checklistRef.current?.applyOriginalRecommendation(itemId);
      },
      addCustomItem: (values) => {
        if (switchingRef.current) return;
        sideCartRef.current?.addCustomItem(values);
      },
      updateCustomItem: (id, values) => {
        if (switchingRef.current) return;
        sideCartRef.current?.updateCustomItem(id, values);
      },
      removeCustomItem: (id) => {
        if (switchingRef.current) return;
        sideCartRef.current?.removeCustomItem(id);
      },
      setGeneralRecommendation: (value) => {
        if (switchingRef.current) return;
        sideCartRef.current?.setGeneralComment(value);
      },
      copySelected: (targetDocument) => {
        if (switchingRef.current) {
          return Promise.reject(new Error(COPY_CLIPBOARD_ERROR_MESSAGE));
        }
        const copy = sideCartRef.current?.copySelectedToClipboard;
        if (!copy) {
          return Promise.reject(new Error(COPY_CLIPBOARD_ERROR_MESSAGE));
        }
        return copy(targetDocument);
      },
    }),
    [],
  );

  const loadAppendixA3 = useCallback((crMId: string | undefined) => {
    const requestId = ++appendixRequestIdRef.current;

    if (!crMId?.trim()) {
      setAppendixA3Tables([]);
      setAppendixA3Error(
        "Для выбранной рекомендации не найден идентификатор приложения А3.",
      );
      setIsAppendixA3Loading(false);
      return;
    }

    setIsAppendixA3Loading(true);
    setAppendixA3Error("");
    fetchEncryptedJson<{ tables?: AppendixA3Table[] }>(
      `/api/cr-tables?cr_m_id=${encodeURIComponent(crMId)}`,
    )
      .then(({ response, data }) => {
        if (requestId !== appendixRequestIdRef.current) return null;
        if (!response.ok || !data) {
          throw new Error("Failed to load Appendix A3 tables");
        }

        return data;
      })
      .then((data) => {
        if (requestId !== appendixRequestIdRef.current || !data) return;
        setAppendixA3Tables(Array.isArray(data.tables) ? data.tables : []);
      })
      .catch(() => {
        if (requestId !== appendixRequestIdRef.current) return;
        setAppendixA3Tables([]);
        setAppendixA3Error(
          "Не удалось загрузить таблицы приложения А3. Попробуйте позже.",
        );
      })
      .finally(() => {
        if (requestId !== appendixRequestIdRef.current) return;
        setIsAppendixA3Loading(false);
      });
  }, []);

  const hydrateFromStorage = useCallback(() => {
    const storedValue = getStoredCartRecommendation();
    if (!storedValue) {
      return false;
    }

    try {
      const parsed = JSON.parse(storedValue) as StoredCartRecommendation;
      const currentRecommendationKey = getRecommendationStorageKey(parsed);
      const storedSelectedItems = normalizeStoredSelectionItems(
        cartStorage.readSelectionsForKey(currentRecommendationKey),
      );

      const currentDiagnosisTitle =
        typeof parsed.diagnosisTitle === "string" ? parsed.diagnosisTitle : "";
      const prescriptions = Array.isArray(parsed.recommendation?.prescriptions)
        ? (parsed.recommendation.prescriptions as ChecklistSection[])
        : [];

      setDiagnosisTitle(currentDiagnosisTitle);
      setDiagnosisCode(getDiagnosisCodeFromTitle(currentDiagnosisTitle));
      setRecommendationId(
        typeof parsed.recommendation?.id === "string" ? parsed.recommendation.id : "",
      );
      setRecommendationSource(
        typeof parsed.recommendation?.source === "string"
          ? parsed.recommendation.source
          : "",
      );
      setRecommendationTitle(
        typeof parsed.recommendation?.title === "string"
          ? parsed.recommendation.title
          : "",
      );
      isRestoringStoredSelectionsRef.current = true;
      syncApplyingRef.current = true;
      setRecommendationKey(currentRecommendationKey);
      recommendationKeyRef.current = currentRecommendationKey;
      baseSectionsRef.current = prescriptions;
      setBaseSections(prescriptions);

      if (currentRecommendationKey && prescriptions.length > 0) {
        const query = collectMedicationQuery(prescriptions);
        medsCatalogSession.ensure(currentRecommendationKey, query.names, query.ids);
      }

      loadAppendixA3(
        typeof parsed.recommendation?.id === "string"
          ? parsed.recommendation.id.trim()
          : undefined,
      );

      setSelectedItems(storedSelectedItems);
      selectedItemsRef.current = storedSelectedItems;
      setAssignmentSnapshot(
        snapshotFromStoredAssignments(
          cartStorage.readAssignmentsForKey(currentRecommendationKey),
        ),
      );
      setAppliedTemplateItems(null);
      setIsCartReady(true);
      setSyncReleaseNonce((value) => value + 1);
      return true;
    } catch {
      return false;
    }
  }, [loadAppendixA3]);

  /**
   * Применить КР из storage к React-state страницы.
   * Remount checklist — через key={recommendationKey} при смене КР.
   * Drafts подтягиваются assignmentHydrateEpoch (в т.ч. если key не изменился).
   */
  const applyRecommendationFromStorage = useCallback(() => {
    if (!hydrateFromStorage()) {
      return false;
    }
    setAssignmentHydrateEpoch((value) => value + 1);
    return true;
  }, [hydrateFromStorage]);

  const handleSelectRecommendation = useCallback(
    async ({
      diagnosisTitle: nextDiagnosisTitle,
      card,
    }: {
      diagnosisTitle: string;
      card: RecommendationStandard;
    }) => {
      const requestId = ++switchRequestIdRef.current;
      const isCurrent = () => requestId === switchRequestIdRef.current;

      setIsSwitchingRecommendation(true);
      try {
        const result = await prepareSelectedRecommendation(
          nextDiagnosisTitle,
          card,
          { isCurrent, beginVisit: true },
        );

        if (!isCurrent()) return;
        if (!result.ok) {
          if (result.stale) return;
          throw new Error(result.error);
        }

        if (!applyRecommendationFromStorage()) {
          throw new Error(
            "Не удалось применить выбранную рекомендацию. Попробуйте позже.",
          );
        }
      } finally {
        if (isCurrent()) {
          setIsSwitchingRecommendation(false);
        }
      }
    },
    [applyRecommendationFromStorage],
  );

  useEffect(() => {
    getCartSync().start();
  }, []);

  useEffect(() => {
    let visit: CartVisit | undefined;
    try {
      visit = JSON.parse(
        window.sessionStorage.getItem(CART_VISIT_STORAGE_KEY) ?? "null",
      ) as CartVisit | undefined;
    } catch {
      return;
    }
    if (!visit?.visitId || !visit.recommendationKey) return;

    void sendOpeningEvent({
      eventId: createEventId(),
      type: "cart_opened",
      ...visit,
    });

    const leaveEventId = createEventId();
    const reportLeave = () => {
      void sendOpeningEvent({
        eventId: leaveEventId,
        type: "cart_left",
        visitId: visit.visitId,
      }, true);
    };
    window.addEventListener("pagehide", reportLeave, { once: true });
    return () => {
      window.removeEventListener("pagehide", reportLeave);
      reportLeave();
    };
  }, []);

  useEffect(() => {
    if (!hydrateFromStorage()) {
      router.replace("/mkb");
      setDiagnosisTitle("");
      setDiagnosisCode("");
      setRecommendationId("");
      setRecommendationSource("");
      setRecommendationTitle("");
      setBaseSections([]);
      baseSectionsRef.current = [];
      setRecommendationKey("");
      setAppendixA3Tables([]);
      setIsAppendixA3Loading(false);
      setAppendixA3Error("");
      setIsCartReady(false);
    }
  }, [hydrateFromStorage, router]);

  useEffect(() => {
    if (syncReleaseNonce === 0) return;
    syncApplyingRef.current = false;
  }, [syncReleaseNonce]);

  useEffect(() => {
    return subscribeCartSync((message) => {
      // Собственный publish уже отражён в React-state этой вкладки.
      if (message.origin === "local") return;

      if (message.scopes.includes("cleared")) {
        router.replace("/mkb");
        return;
      }

      if (message.scopes.includes("recommendation")) {
        if (!applyRecommendationFromStorage()) {
          router.replace("/mkb");
        }
        return;
      }

      const storedRecommendation = cartStorage.readRecommendation();
      const key = storedRecommendation
        ? getRecommendationStorageKey(storedRecommendation)
        : recommendationKeyRef.current;
      if (!key) return;

      const hasSelections = message.scopes.includes("selections");
      const hasAssignments = message.scopes.includes("assignments");
      if (!hasSelections && !hasAssignments) return;

      syncApplyingRef.current = true;
      isRestoringStoredSelectionsRef.current = true;

      if (
        Array.isArray(storedRecommendation?.recommendation?.prescriptions)
      ) {
        const prescriptions = storedRecommendation.recommendation
          .prescriptions as ChecklistSection[];
        baseSectionsRef.current = prescriptions;
        setBaseSections((prev) =>
          sameBaseSectionIds(prev, prescriptions) ? prev : prescriptions,
        );
      }

      if (hasAssignments) {
        setAssignmentSnapshot(
          snapshotFromStoredAssignments(cartStorage.readAssignmentsForKey(key)),
        );
        setAssignmentHydrateEpoch((value) => value + 1);
      }

      if (hasSelections) {
        const nextItems = cartStorage.readSelectionsForKey(key);
        if (!sameSelectionIds(selectedItemsRef.current, nextItems)) {
          setSelectedItems(nextItems);
          selectedItemsRef.current = nextItems;
          setAppliedTemplateItems(null);
        }
      }

      if (key !== recommendationKeyRef.current) {
        setRecommendationKey(key);
        recommendationKeyRef.current = key;
      }

      // Снять suppress после эффектов checklist (не microtask — иначе гонка записи).
      setSyncReleaseNonce((value) => value + 1);
    });
  }, [applyRecommendationFromStorage, router]);

  const handleSelectionChange = useCallback((items: SelectedPrescription[]) => {
    if (syncApplyingRef.current || isRestoringStoredSelectionsRef.current) {
      selectedItemsRef.current = items;
      isRestoringStoredSelectionsRef.current = false;
      return;
    }

    if (sameSelectionIds(selectedItemsRef.current, items)) {
      return;
    }

    setSelectedItems(items);
    selectedItemsRef.current = items;
    writeStoredSelections(recommendationKey, items);
  }, [recommendationKey]);

  const handleDeleteItem = (id: string) => {
    setSelectedItems((prev) => {
      const nextItems = prev.filter((item) => item.id !== id);
      selectedItemsRef.current = nextItems;
      writeStoredSelections(recommendationKey, nextItems);
      return nextItems;
    });
    setUncheckItemId(id);
  };

  const handleDeleteAll = () => {
    setSelectedItems([]);
    selectedItemsRef.current = [];
    writeStoredSelections(recommendationKey, []);
    setClearSelectionSignal((prev) => prev + 1);
    setAppliedTemplateItems(null);
  };

  const handleApplyTemplate = (template: CartTemplate) => {
    setSelectedItems(template.items);
    selectedItemsRef.current = template.items;
    setAppliedTemplateItems(template.items);
    writeStoredSelections(recommendationKey, template.items);
  };

  const miniCartData = useDirectoryMiniCartData({
    diagnosisTitle,
    sections: checklistSections,
    recommendationKey,
    appendixA3Tables,
    isAppendixA3Loading,
    appendixA3Error,
    assignment: assignmentSnapshot,
  });

  if (!isCartReady) {
    return null;
  }
  
  const fullCartVisible = miniCartMode === "full";

  return (
    <>
      <DirectoryPageHeader
        variant="cart"
        diagnosisTitle={diagnosisTitle}
        recommendationId={recommendationId}
        recommendationSource={recommendationSource}
        onCollapse={handleMiniCartCollapse}
        collapseHidden={!fullCartVisible}
      />
      <main
        className={styles.page}
        hidden={!fullCartVisible}
        aria-hidden={!fullCartVisible}
      >
      <section className={styles.layout}>
        <PrescriptionChecklist
          ref={checklistRef}
          key={recommendationKey || "cart-checklist"}
          onSelectionChange={handleSelectionChange}
          onAssignmentSnapshotChange={handleAssignmentSnapshotChange}
          initialAssignment={assignmentSnapshot}
          assignmentHydrateEpoch={assignmentHydrateEpoch}
          uncheckItemId={uncheckItemId}
          onUncheckHandled={() => setUncheckItemId(null)}
          clearSelectionSignal={clearSelectionSignal}
          initialSections={checklistSections}
          appliedTemplateItems={appliedTemplateItems}
          appendixA3Tables={appendixA3Tables}
          isAppendixA3Loading={isAppendixA3Loading}
          appendixA3Error={appendixA3Error}
          medsRecommendationKey={recommendationKey}
        />
        <SideCart
          ref={sideCartRef}
          selectedItems={selectedItems}
          assignment={assignmentSnapshot}
          onDeleteItem={handleDeleteItem}
          onDeleteAll={handleDeleteAll}
          onApplyTemplate={handleApplyTemplate}
          diagnosisCode={diagnosisCode}
          recommendationTitle={recommendationTitle}
          storageKey={recommendationKey}
        />
      </section>
      </main>
      <MiniCartHost
        ref={miniCartRef}
        diagnosis={miniCartData.diagnosis}
        tabs={miniCartData.tabs}
        drugItems={miniCartData.drugItems}
        shellTabs={miniCartData.shellTabs}
        trades={miniCartData.trades}
        recommendationText={miniCartData.recommendation}
        customItems={miniCartData.customItems}
        schemeByItemId={miniCartData.schemeByItemId}
        assignmentOps={miniCartAssignmentOps}
        contentKey={recommendationKey}
        onSelectRecommendation={handleSelectRecommendation}
        displayMode={miniCartMode}
        onDisplayModeChange={setMiniCartMode}
        getPipHeightSource={() => sideCartRef.current?.getRootElement() ?? null}
      />
    </>
  );
}
