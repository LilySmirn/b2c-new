"use client";

import { type FocusEvent, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import SearchBar from "../components/SearchBar";
import LoadingSpinner from "../components/LoadingSpinner";
import Filters from "../components/Filters";
import MatchesList from "../components/MatchesList";
import Bookmarks, { type BookmarkItem } from "../components/Bookmarks";
import styles from "./search.module.css";
import Image from "next/image";
import DirectoryPageHeader from "../components/DirectoryPageHeader";
import logoBig from "@/assets/images/logo-big.svg";
import RecommendationCard from "../components/RecommendationCard";
import SuggestedCodesList from "../components/SuggestedCodesList";
import { fetchEncryptedJson } from "@/app/lib/encryptedPayload/client";
import { isMkbCodeAllowed, normalizeMkbCode } from "@/app/lib/mkbCodeAccess";
import { USER_BLOCKING_REFRESH_EVENT } from "@/app/modules/userBlocking";
import { handleInvalidB2cSession } from "@/app/lib/handleInvalidB2cSession";
import { readSearchState, writeSearchState } from "@/app/lib/searchStateStorage";
import { normalizeMkbSearchInput } from "@/app/lib/normalizeMkbSearchInput";
import {
  DEMO_LIMIT_MESSAGE,
  ageOptions,
  formatDemoRemaining,
  formatMkbResult,
  getAvailableFilters,
  getCartRecommendationKey,
  getCodeFromMatch,
  getRecommendationExternalUrl,
  hasDataForFilters,
  isAgeGroup,
  isDemoLimitResponse,
  isVisitType,
  prepareSelectedRecommendation,
  visitOptions,
  type AgeGroup,
  type FilterAvailability,
  type MkbDataResponse,
  type MkbSearchResult,
  type RecommendationStandard,
  type VisitType,
} from "@/app/(directory)/shared/mkb";
import NoTranslate from "@/app/components/NoTranslate";

type MkbAccessResponse = {
  allowedCodes: string[] | null;
};

type DemoAccessStatus = {
  hasActiveSubscription: boolean;
  limit: number;
  used: number;
  remaining: number;
};

type StoredSearchState = {
  query?: string;
  visitType?: VisitType;
  ageGroup?: AgeGroup;
  submittedCode?: string | null;
  submittedDiagnosisTitle?: string | null;
  apiMatches?: MkbSearchResult[];
  mkbData?: MkbDataResponse | null;
};

const readStoredSearchState = (): StoredSearchState | null => {
  if (typeof window === "undefined") return null;

  return readSearchState<StoredSearchState>(window.sessionStorage);
};

const writeStoredSearchState = (state: StoredSearchState) => {
  writeSearchState(window.sessionStorage, state);
};

export default function SearchPreviewPage() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [visitType, setVisitType] = useState<VisitType>("primary");
  const [ageGroup, setAgeGroup] = useState<AgeGroup>("adult");
  const [isMatchesOpen, setIsMatchesOpen] = useState(false);
  const [submittedCode, setSubmittedCode] = useState<string | null>(null);
  const [submittedDiagnosisTitle, setSubmittedDiagnosisTitle] = useState<string | null>(null);
  const [apiMatches, setApiMatches] = useState<MkbSearchResult[]>([]);
  const [filterAvailability, setFilterAvailability] = useState<FilterAvailability | null>(null);
  const [isSearchLoading, setIsSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [mkbData, setMkbData] = useState<MkbDataResponse | null>(null);
  const [cardsError, setCardsError] = useState<string | null>(null);
  const [allowedMkbCodes, setAllowedMkbCodes] = useState<string[] | null | undefined>(undefined);
  const [isMkbAccessLoaded, setIsMkbAccessLoaded] = useState(false);
  const [mkbAccessError, setMkbAccessError] = useState<string | null>(null);
  const [medsLoadingKey, setMedsLoadingKey] = useState<string | null>(null);
  const [medsError, setMedsError] = useState<string | null>(null);
  const medsRequestRef = useRef(0);
  const medsLoadingKeyRef = useRef<string | null>(null);
  const medsNavigatingRef = useRef(false);
  const medsRetryRef = useRef<{
    diagnosisTitle: string;
    card: RecommendationStandard;
  } | null>(null);
  const [isCardsLoading, setIsCardsLoading] = useState(false);
  const [demoRemaining, setDemoRemaining] = useState<number | null>(null);
  const searchDropdownRef = useRef<HTMLDivElement>(null);
  const hasRestoredSearchStateRef = useRef(false);
  const restoredMatchesSearchRef = useRef<string | null>(null);
  const restoredMkbDataCodeRef = useRef<string | null>(null);
  const demoResponseVersionRef = useRef(0);

  useEffect(() => {
    const controller = new AbortController();

    const loadMkbAccess = async () => {
      try {
        const response = await fetch("/api/mkb-access", { signal: controller.signal });
        if (!response.ok) throw new Error("Не удалось проверить доступные коды МКБ");

        const data = (await response.json()) as MkbAccessResponse;
        setAllowedMkbCodes(data.allowedCodes);
      } catch (error) {
        if ((error as Error).name === "AbortError") return;
        setMkbAccessError("Не удалось проверить доступные коды МКБ. Попробуйте позже.");
      } finally {
        setIsMkbAccessLoaded(true);
      }
    };

    loadMkbAccess();
    return () => controller.abort();
  }, []);

  useEffect(() => {
    const controller = new AbortController();

    const loadDemoAccess = async () => {
      const responseVersion = demoResponseVersionRef.current;

      try {
        const response = await fetch("/api/mkb-demo-access", {
          signal: controller.signal,
          cache: "no-store",
        });
        if (!response.ok) return;

        const status = (await response.json()) as DemoAccessStatus;
        if (demoResponseVersionRef.current === responseVersion) {
          setDemoRemaining(status.hasActiveSubscription ? null : status.remaining);
        }
      } catch (error) {
        if ((error as Error).name !== "AbortError") setDemoRemaining(null);
      }
    };

    loadDemoAccess();
    return () => controller.abort();
  }, []);

  const updateDemoRemainingFromResponse = (response: Response) => {
    const headerValue = response.headers.get("X-Demo-Remaining");
    if (headerValue === null) return;

    const remaining = Number(headerValue);
    if (Number.isInteger(remaining)) {
      demoResponseVersionRef.current += 1;
      setDemoRemaining(Math.max(0, remaining));
    }
  };

  useEffect(() => {
    if (hasRestoredSearchStateRef.current) return;

    const storedSearchState = readStoredSearchState();

    if (!storedSearchState) {
      hasRestoredSearchStateRef.current = true;
      return;
    }

    if (typeof storedSearchState.query === "string") {
      setQuery(storedSearchState.query);
    }

    if (isVisitType(storedSearchState.visitType)) {
      setVisitType(storedSearchState.visitType);
    }

    if (isAgeGroup(storedSearchState.ageGroup)) {
      setAgeGroup(storedSearchState.ageGroup);
    }

    if (Array.isArray(storedSearchState.apiMatches)) {
      setApiMatches(storedSearchState.apiMatches);
      restoredMatchesSearchRef.current = storedSearchState.query?.trim() ?? null;
    }

    const storedMkbData = storedSearchState.mkbData;
    const storedSubmittedCode = storedSearchState.submittedCode;
    const hasCompletedStoredSearch = Boolean(storedMkbData && storedSubmittedCode);

    if (storedMkbData && storedSubmittedCode) {
      setMkbData(storedMkbData);
      setFilterAvailability(storedMkbData.availability);
      restoredMkbDataCodeRef.current = storedSubmittedCode;
    }

    // A code without its completed response represents an interrupted/failed
    // request. Keep the query text, but require an explicit retry so a reload
    // never consumes another demo request by itself.
    setSubmittedCode(hasCompletedStoredSearch ? storedSubmittedCode ?? null : null);
    setSubmittedDiagnosisTitle(
      hasCompletedStoredSearch ? storedSearchState.submittedDiagnosisTitle ?? null : null,
    );

    window.setTimeout(() => {
      hasRestoredSearchStateRef.current = true;
    }, 0);
  }, []);

  useEffect(() => {
    if (!hasRestoredSearchStateRef.current) return;

    writeStoredSearchState({
      query,
      visitType,
      ageGroup,
      submittedCode,
      submittedDiagnosisTitle,
      apiMatches,
      mkbData,
    });
  }, [ageGroup, apiMatches, mkbData, query, submittedCode, submittedDiagnosisTitle, visitType]);

  const search = query.trim();
  const matches = useMemo(() => apiMatches.map(formatMkbResult), [apiMatches]);
  const normalizedSearchCode = useMemo(() => {
    const code = search.match(/^[A-ZА-Я]\d{2}(?:\.\d+)?/i)?.[0];

    return code ? code.toUpperCase() : null;
  }, [search]);

  const selectedCode = useMemo(() => {
    const exactMatch = apiMatches.find((item) => formatMkbResult(item) === query);
    if (exactMatch) return exactMatch.code;

    return normalizedSearchCode ? getCodeFromMatch(normalizedSearchCode) : null;
  }, [apiMatches, normalizedSearchCode, query]);

  useEffect(() => {
    if (restoredMatchesSearchRef.current !== null) {
      if (restoredMatchesSearchRef.current === search) {
        restoredMatchesSearchRef.current = null;
      }
      return;
    }
    if (search.length < 3) {
      setApiMatches([]);
      setIsSearchLoading(false);
      setSearchError(null);
      return;
    }

    const controller = new AbortController();
    const timeoutId = window.setTimeout(async () => {
      setIsSearchLoading(true);
      setSearchError(null);

      try {
        const response = await fetch(
          `/api/search?search=${encodeURIComponent(search)}`,
          { signal: controller.signal, cache: "no-store" },
        );

        if (await handleInvalidB2cSession(response)) return;

        if (!response.ok) {
          throw new Error("Не удалось получить данные поиска");
        }

        const data = (await response.json()) as MkbSearchResult[];
        setApiMatches(data);
      } catch (error) {
        if ((error as Error).name === "AbortError") return;

        setApiMatches([]);
        setSearchError("Не удалось загрузить подсказки. Попробуйте позже.");
      } finally {
        setIsSearchLoading(false);
      }
    }, 300);

    return () => {
      window.clearTimeout(timeoutId);
      controller.abort();
    };
  }, [search]);

  useEffect(() => {
    if (restoredMkbDataCodeRef.current !== null) {
      if (restoredMkbDataCodeRef.current === submittedCode) {
        restoredMkbDataCodeRef.current = null;
      }
      return;
    }

    if (!submittedCode) {
      setMkbData(null);
      setFilterAvailability(null);
      setCardsError(null);
      setIsCardsLoading(false);
      return;
    }

    const controller = new AbortController();

    const loadMkbData = async () => {
      setIsCardsLoading(true);
      setCardsError(null);

      try {
        const { response, data } = await fetchEncryptedJson<MkbDataResponse>(
          `/api/mkb-data?code=${encodeURIComponent(submittedCode)}`,
          { signal: controller.signal, cache: "no-store" },
        );

        if (await handleInvalidB2cSession(response)) return;

        updateDemoRemainingFromResponse(response);

        if (response.headers.get("X-User-Blocked") === "true") {
          window.dispatchEvent(new Event(USER_BLOCKING_REFRESH_EVENT));
        }
        if (await isDemoLimitResponse(response)) {
          setMkbData(null);
          setFilterAvailability(null);
          setCardsError(DEMO_LIMIT_MESSAGE);
          return;
        }
        if (!response.ok || !data) throw new Error("Не удалось получить данные по коду МКБ");

        setMkbData(data);
        setFilterAvailability(data.availability);
      } catch (error) {
        if ((error as Error).name === "AbortError") return;
        setMkbData(null);
        setFilterAvailability(null);
        setCardsError("Не удалось загрузить данные по коду МКБ. Попробуйте позже.");
      } finally {
        setIsCardsLoading(false);
      }
    };

    loadMkbData();

    return () => controller.abort();
  }, [submittedCode]);

  useEffect(() => {
    if (!filterAvailability || hasDataForFilters(filterAvailability, ageGroup, visitType)) return;

    const fallback = getAvailableFilters(filterAvailability, ageGroup, visitType);

    if (fallback) {
      setAgeGroup(fallback.age);
      setVisitType(fallback.visit);
    }
  }, [ageGroup, filterAvailability, visitType]);

  useEffect(() => {
    if (!isMatchesOpen) return;

    const handlePointerDown = (event: PointerEvent) => {
      if (!searchDropdownRef.current?.contains(event.target as Node)) {
        setIsMatchesOpen(false);
      }
    };

    document.addEventListener("pointerdown", handlePointerDown);

    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
    };
  }, [isMatchesOpen]);

  const disabledVisitIds = useMemo(() => {
    if (!filterAvailability) return [];

    return visitOptions
      .filter((option) => !hasDataForFilters(filterAvailability, ageGroup, option.id as VisitType))
      .map((option) => option.id);
  }, [ageGroup, filterAvailability]);

  const disabledAgeIds = useMemo(() => {
    if (!filterAvailability) return [];

    return ageOptions
      .filter((option) => !hasDataForFilters(filterAvailability, option.id as AgeGroup, visitType))
      .map((option) => option.id);
  }, [filterAvailability, visitType]);

  const getDiagnosisTitle = (code: string, sourceText = query) => {
    const formattedMatch = sourceText.trim();
    if (getCodeFromMatch(formattedMatch).toUpperCase() === code.toUpperCase() && formattedMatch.includes(":")) {
      return formattedMatch;
    }

    const apiMatch = apiMatches.find((item) => item.code.toUpperCase() === code.toUpperCase());

    return apiMatch ? formatMkbResult(apiMatch) : code;
  };

  const handleQueryChange = (value: string) => {
    setQuery(normalizeMkbSearchInput(value));
    setMkbAccessError(null);
    setSubmittedCode(null);
    setSubmittedDiagnosisTitle(null);
  };

  const isSubmittedQueryFocused = Boolean(
    submittedCode &&
      query.trim() &&
      (query === submittedDiagnosisTitle || query.trim().toUpperCase() === submittedCode.toUpperCase()),
  );

  const shouldHideSubmittedQueryEmptyDropdown = Boolean(
    isSubmittedQueryFocused && matches.length === 0 && !isSearchLoading && !searchError,
  );

  const handleSearchFocus = (event: FocusEvent<HTMLInputElement>) => {
    if (isSubmittedQueryFocused) {
      event.currentTarget.select();
    }

    setIsMatchesOpen(true);
  };

  const submitSearch = (code = selectedCode, diagnosisTitle?: string) => {
    setIsMatchesOpen(false);

    if (!code) return;

    const normalizedCode = normalizeMkbCode(code);
    if (!isMkbAccessLoaded) {
      setMkbAccessError("Проверяем доступные для аккаунта коды. Повторите поиск.");
      return;
    }

    if (allowedMkbCodes === undefined) {
      setMkbAccessError("Не удалось проверить доступные коды МКБ. Попробуйте позже.");
      return;
    }

    if (allowedMkbCodes !== null && !isMkbCodeAllowed(normalizedCode, allowedMkbCodes)) {
      setMkbAccessError(
        `Для этого аккаунта доступны следующие коды: ${allowedMkbCodes.join(", ")}`,
      );
      return;
    }

    setMkbAccessError(null);

    setSubmittedCode(normalizedCode);
    setSubmittedDiagnosisTitle(diagnosisTitle ?? getDiagnosisTitle(normalizedCode));
  };

  const handleMatchSelect = (item: string) => {
    setQuery(item);
    submitSearch(getCodeFromMatch(item), item);
  };

  const recommendationCards = useMemo(
    () => mkbData?.standards[ageGroup][visitType] ?? [],
    [ageGroup, mkbData, visitType],
  );
  const cardDiagnosisTitle = submittedDiagnosisTitle ?? submittedCode;
  const medsLoadingCardVisible = Boolean(
    medsLoadingKey &&
      recommendationCards.some(
        (card) =>
          getCartRecommendationKey(cardDiagnosisTitle ?? card.title, card) === medsLoadingKey,
      ),
  );
  const recommendedMatches = useMemo(
    () => (ageGroup === "child" ? mkbData?.recommendations.child : mkbData?.recommendations.grownup) ?? [],
    [ageGroup, mkbData],
  );

  const shouldShowRecommendations = Boolean(
    submittedCode && !isCardsLoading && !cardsError && recommendationCards.length === 0,
  );

  const getBookmarkDiagnosisTitle = (bookmark: BookmarkItem, recommendationTitle?: string) => {
    const clinicalRecommendationTitle = recommendationTitle?.trim() || bookmark.recommendationTitle?.trim();

    if (clinicalRecommendationTitle) {
      return `${bookmark.code}: ${clinicalRecommendationTitle}`;
    }
    const bookmarkTitle = bookmark.title.trim();

    return getCodeFromMatch(bookmarkTitle).toUpperCase() === bookmark.code.toUpperCase() &&
      bookmarkTitle.includes(":")
      ? bookmarkTitle
      : `${bookmark.code}: ${bookmarkTitle}`;
  };

  const releaseMedsLoading = (recommendationKey: string) => {
    if (medsLoadingKeyRef.current === recommendationKey) {
      medsLoadingKeyRef.current = null;
    }
    setMedsLoadingKey((current) => (current === recommendationKey ? null : current));
  };

  const openSelectedRecommendation = async (
    diagnosisTitle: string,
    card: RecommendationStandard,
  ) => {
    if (medsNavigatingRef.current) return;

    const recommendationKey = getCartRecommendationKey(diagnosisTitle, card);
    if (medsLoadingKeyRef.current === recommendationKey) return;

    const requestId = ++medsRequestRef.current;
    const isCurrent = () => requestId === medsRequestRef.current;
    medsLoadingKeyRef.current = recommendationKey;
    medsRetryRef.current = { diagnosisTitle, card };
    setMedsError(null);
    setMedsLoadingKey(recommendationKey);

    const result = await prepareSelectedRecommendation(diagnosisTitle, card, {
      isCurrent,
      beginVisit: true,
    });

    if (!isCurrent()) {
      releaseMedsLoading(recommendationKey);
      return;
    }

    if (!result.ok) {
      releaseMedsLoading(recommendationKey);
      if (result.stale) return;
      setMedsError(result.error);
      return;
    }

    medsNavigatingRef.current = true;
    releaseMedsLoading(recommendationKey);
    router.push("/cart");
  };

  const retryMedsLoad = () => {
    const retry = medsRetryRef.current;
    if (!retry) return;
    void openSelectedRecommendation(retry.diagnosisTitle, retry.card);
  };

  const handleBookmarkSelect = async (bookmark: BookmarkItem) => {
    const bookmarkVisitType = isVisitType(bookmark.visitType) ? bookmark.visitType : visitType;
    const bookmarkAgeGroup = isAgeGroup(bookmark.ageGroup) ? bookmark.ageGroup : ageGroup;

    try {
      const { response, data } = await fetchEncryptedJson<MkbDataResponse>(
        `/api/mkb-data?code=${encodeURIComponent(bookmark.code)}`,
        { cache: "no-store" },
      );

      if (await handleInvalidB2cSession(response)) return;

      updateDemoRemainingFromResponse(response);

      if (await isDemoLimitResponse(response)) {
        setCardsError(DEMO_LIMIT_MESSAGE);
        return;
      }
      if (!response.ok || !data) throw new Error("Не удалось получить данные по коду МКБ");
      const availableFilters = getAvailableFilters(
        data.availability,
        bookmarkAgeGroup,
        bookmarkVisitType,
      );
      if (!availableFilters) {
        setCardsError("По выбранной закладке клинические рекомендации не найдены.");
        return;
      }

      const selectedCard = data.standards[availableFilters.age][availableFilters.visit][0];

      if (!selectedCard) {
        setCardsError("По выбранной закладке клинические рекомендации не найдены.");
        return;
      }

      const diagnosisTitle = getBookmarkDiagnosisTitle(bookmark, selectedCard.title);
      await openSelectedRecommendation(diagnosisTitle, selectedCard);
    } catch (error) {
      setCardsError("Не удалось открыть закладку. Попробуйте позже.");
    }
  };

  const handleCardSelect = (card: RecommendationStandard) => {
    const diagnosisTitle = submittedDiagnosisTitle ?? submittedCode ?? card.title;

    writeStoredSearchState({
      query,
      visitType,
      ageGroup,
      submittedCode,
      submittedDiagnosisTitle,
      apiMatches,
      mkbData,
    });

    void openSelectedRecommendation(diagnosisTitle, card);
  };

  const matchesEmptyText = (() => {
    if (search.length < 3) return "Введите минимум 3 символа";
    if (isSearchLoading) return <LoadingSpinner>Ищем в базе МКБ...</LoadingSpinner>;
    return "Ничего не найдено";
  })();

  return (
    <>
      <DirectoryPageHeader variant="search" />
      <main className={styles.wrapper}>
        <section className={styles.content}>
          <span className="notranslate" translate="no">
            <Image src={logoBig} alt="EasyMed" className={styles.logo} priority />
          </span>

          {demoRemaining !== null ? (
            demoRemaining > 0 ? (
              <p className={styles.demoRemaining} aria-live="polite">
                {formatDemoRemaining(demoRemaining)}
              </p>
            ) : (
              <p className={styles.demoLimitMessage} role="alert">
                Бесплатные 5 запросов на сегодня закончились. Для снятия ограничения{" "}
                <strong><Link href="/profile">приобретите подписку</Link></strong>.
              </p>
            )
          ) : null}

          <div
            className={styles.searchDropdown}
            ref={searchDropdownRef}
            data-open={isMatchesOpen}
          >
            <SearchBar
              value={query}
              onChange={handleQueryChange}
              onFocus={handleSearchFocus}
              onSearch={() => submitSearch()}
              variant="connected"
            />

            {isMatchesOpen && !shouldHideSubmittedQueryEmptyDropdown && (
              <MatchesList
                items={matches}
                emptyText={matchesEmptyText}
                footerText={searchError}
                onItemSelect={handleMatchSelect}
              />
            )}
          </div>

          {mkbAccessError ? (
            <p className={styles.mkbAccessError} role="alert">{mkbAccessError}</p>
          ) : null}

          <Filters
            visitOptions={visitOptions}
            visitValue={visitType}
            onVisitChange={(value) => setVisitType(value as VisitType)}
            ageOptions={ageOptions}
            ageValue={ageGroup}
            onAgeChange={(value) => setAgeGroup(value as AgeGroup)}
            disabledVisitIds={disabledVisitIds}
            disabledAgeIds={disabledAgeIds}
          />

          <Bookmarks onBookmarkSelect={handleBookmarkSelect} />

          {medsError ? (
            <p className={styles.medsLoadError} role="alert">
              {medsError}{" "}
              <button type="button" className={styles.medsRetry} onClick={retryMedsLoad}>
                Повторить
              </button>
            </p>
          ) : null}

          {medsLoadingKey && !medsLoadingCardVisible ? (
            <p className={styles.recommendationsMessage}>
              <LoadingSpinner>Загружаем препараты…</LoadingSpinner>
            </p>
          ) : null}

            {submittedCode ? (
            <section className={styles.recommendationsSection} aria-label="Клинические рекомендации">
              {isCardsLoading ? (
                <p className={styles.recommendationsMessage}>
                  <LoadingSpinner>Загружаем клинические рекомендации...</LoadingSpinner>
                </p>
              ) : cardsError ? (
                cardsError === DEMO_LIMIT_MESSAGE ? null : (
                  <p className={styles.recommendationsMessage}>{cardsError}</p>
                )
              ) : recommendationCards.length > 0 ? (
                <div className={styles.recommendationsGrid}>
                  {recommendationCards.map((card) => {
                    const cardKey = getCartRecommendationKey(
                      cardDiagnosisTitle ?? card.title,
                      card,
                    );

                    return (
                    <RecommendationCard
                      key={`${card.id}-${card.title}`}
                      title={card.title}
                      externalUrl={getRecommendationExternalUrl(card.source, card.id)}
                      standardId={card.id}
                      status={card.status}
                      ageCategory={card.ageCategory}
                      dateApprovement={card.dateApprovement}
                      dateReview={card.dateReview}
                      classification={card.mkbCodes.length > 0 ? card.mkbCodes.join(", ") : submittedCode}
                      busy={medsLoadingKey === cardKey}
                      onSelect={() => handleCardSelect(card)}
                    />
                    );
                  })}
                </div>
              ) : null}
            </section>
          ) : null}

          {shouldShowRecommendations && submittedCode ? (
            <section className={styles.emptyStateSection} aria-label="Рекомендованные коды МКБ">
              {recommendedMatches.length > 0 ? (
                <>
                  <p className={styles.emptyStateText}>
                    По выбранному МКБ{" "}
                    <strong>
                      <NoTranslate>{submittedCode}</NoTranslate>
                    </strong>{" "}
                    рекомендации не найдены.
                    <br />
                    Возможно, вам подойдут следующие коды:
                  </p>
                  <SuggestedCodesList
                    items={recommendedMatches.map(formatMkbResult)}
                    onItemSelect={(item) => handleMatchSelect(item)}
                  />
                </>
              ) : (
                <p className={styles.emptyStateText}>
                  По выбранному МКБ{" "}
                  <strong>
                    <NoTranslate>{submittedCode}</NoTranslate>
                  </strong>{" "}
                  у Минздрава клинических рекомендаций и стандартов не предусмотрено
                </p>
              )}
            </section>
          ) : null}

        </section>
      </main>
    </>
  );
}