"use client";

import Image from 'next/image';
import Link from 'next/link';
import eagleWhiteIcon from '@/assets/images/eagle-white.png';
import starLogo from '@/assets/images/star_logo.png';
import searchIcon from '@/assets/images/search.svg';
import styles from './DirectoryPageHeader.module.css';
import SubscriptionExpirationWarning from '@/app/(directory)/components/SubscriptionExpirationWarning';
import { logout } from '@/app/lib/logout';
import { getSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import { clearDirectoryCartState } from '@/app/(directory)/shared/cart';

type DirectoryPageHeaderProps = {
  variant: 'search' | 'cart';
  diagnosisTitle?: string;
  recommendationId?: string;
  recommendationSource?: string;
  /** Кнопка «Свернуть» (мини-корзинка). Только cart. */
  onCollapse?: () => void;
  collapseHidden?: boolean;
};

const getRecommendationExternalUrl = (source: string, id?: string) => {
  const normalizedSource = source.trim().toLowerCase();
  const normalizedId = id?.trim();

  if (normalizedSource === "minzdrav" && normalizedId) {
    return `https://cr.minzdrav.gov.ru/view-cr/${encodeURIComponent(normalizedId)}`;
  }

  if (normalizedSource === "star") {
    return "https://e-stomatology.ru/director/protokols/";
  }

  return "https://cr.minzdrav.gov.ru/";
};

const getSourceMeta = (source?: string, id?: string) => {
  const normalizedSource = source?.trim().toLowerCase();

  if (!normalizedSource) return null;

  if (normalizedSource === "star") {
    return {
      icon: starLogo,
      iconType: "image" as const,
      label: "СтАР",
      title: "Открыть источник документа: СтАР",
      url: getRecommendationExternalUrl(source ?? "", id),
    };
  }

  if (normalizedSource === "minzdrav") {
    return {
      icon: eagleWhiteIcon,
      iconType: "image" as const,
      label: "Рубрикатор",
      title: "Открыть документ в рубрикаторе Минздрава",
      url: getRecommendationExternalUrl(source ?? "", id),
    };
  }

  return {
    icon: "↗",
    iconType: "text" as const,
    label: source?.trim() ?? "Источник",
    title: `Открыть источник документа: ${source}`,
    url: getRecommendationExternalUrl(source ?? "", id),
  };
};

const clearAuthCookies = () => {
  ['username', 'password'].forEach((cookieName) => {
    document.cookie = `${cookieName}=; path=/; max-age=0; SameSite=Lax`;
  });
};

export default function DirectoryPageHeader({
  variant,
  diagnosisTitle,
  recommendationId,
  recommendationSource,
  onCollapse,
  collapseHidden = false,
}: DirectoryPageHeaderProps) {
  const sourceMeta = getSourceMeta(recommendationSource, recommendationId);
  const [isB2cUser, setIsB2cUser] = useState(false);

  useEffect(() => {
    if (variant === 'search') {
      void getSession().then((session) => {
        setIsB2cUser(session?.user?.accountType === 'b2c');
      });
    }
  }, [variant]);

  const handleBackToSearch = () => {
    clearDirectoryCartState();
  };

  const handleLogout = async (event: React.MouseEvent<HTMLAnchorElement>) => {
    event.preventDefault();
    clearAuthCookies();
    clearDirectoryCartState();
    await logout();
  };
  
  const action =
    variant === 'cart' ? (
      <div className={styles.cartActions}>
        {onCollapse && !collapseHidden ? (
          <button
            type="button"
            className={`${styles.action} ${styles.collapseAction}`}
            onClick={onCollapse}
            aria-pressed="false"
          >
            Свернуть
          </button>
        ) : null}
        {sourceMeta ? (
          <a
            href={sourceMeta.url}
            className={`${styles.action} ${styles.sourceAction}`}
            title={sourceMeta.title}
            target="_blank"
            rel="noreferrer"
          >
            <span className={styles.sourceIcon} aria-hidden="true">
              {sourceMeta.iconType === "image" ? (
                <Image src={sourceMeta.icon} alt="" width={22} height={22} />
              ) : (
                sourceMeta.icon
              )}
            </span>
            <span className={styles.sourceLabel}>{sourceMeta.label}</span>
          </a>
        ) : null}
        <Link
          href="/mkb"
          className={`${styles.action} ${styles.backAction}`}
          onClick={handleBackToSearch}
        >
          <Image src={searchIcon} alt="" width={18} height={18} className={styles.searchIcon} />
          Вернуться к поиску
        </Link>
      </div>
    ) : isB2cUser ? (
      <Link href="/profile" className={styles.action}>
        Личный кабинет
      </Link>
    ) : (
      <Link href="/auth" className={styles.action} onClick={handleLogout}>
        Выйти
      </Link>
    );

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link href="/" className={`${styles.logoLink} notranslate`} translate="no">
          <Image
            src="/images/logo-white.png"
            alt="Клинические рекомендации Минздрава — логотип"
            width={101}
            height={43}
            loading="eager"
          />
        </Link>
        <div className={styles.headerMessages}>
          {variant === 'cart' && diagnosisTitle ? (
            <p className={styles.diagnosisTitle}>{diagnosisTitle}</p>
          ) : null}
          <SubscriptionExpirationWarning />
        </div>
        {action}
      </div>
    </header>
  );
}