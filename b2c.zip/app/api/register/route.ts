import db from "../../lib/db";
import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { User } from "@/app/types/User";
import { v4 as uuidv4 } from "uuid";
import crypto from "crypto";
import { sendMail } from "@/app/lib/mailer";
import { getPasswordValidationError } from "@/app/lib/passwordValidation";
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type RegistrationStatus =
    | "already_verified"
    | "verification_pending"
    | "verification_resent"
    | "verification_sent";

function getPublicBaseUrl(req: Request): string {
    const configuredUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL;

    if (configuredUrl) {
        return configuredUrl.replace(/\/$/, "");
    }

    const host = req.headers.get("host") ?? "localhost:3000";
    const protocol = req.headers.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");

    return `${protocol}://${host}`;
}

function buildVerificationEmail(name: string, verificationUrl: string): string {
    return `
        <p>Здравствуйте, ${name}!</p>
        <p>Для завершения регистрации в EasyMed подтвердите адрес электронной почты.</p>
        <p><a href="${verificationUrl}">Подтвердить email</a></p>
        <p>Ссылка действует 24 часа.</p>
    `;
}

type RegisterPayload = {
    email?: unknown;
    password?: unknown;
    name?: unknown;
};

function isRegisterPayload(payload: unknown): payload is RegisterPayload {
    return Boolean(payload && typeof payload === "object");
}

function isDuplicateKeyError(error: unknown): boolean {
    return Boolean(
        error &&
        typeof error === "object" &&
        "code" in error &&
        (error as { code?: unknown }).code === "ER_DUP_ENTRY"
    );
}

function validateRegisterPayload(payload: unknown) {
    const body = isRegisterPayload(payload) ? payload : {};
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";

    if (!name) {
        return { error: "Name is required" };
    }

    if (!email || !EMAIL_PATTERN.test(email)) {
        return { error: "Valid email is required" };
    }

    const passwordError = getPasswordValidationError(password);
    if (passwordError) {
        return { error: passwordError };
    }

    return { value: { email, password, name } };
}

export async function POST(req: Request) {
    const validation = validateRegisterPayload(await req.json().catch(() => null));

    if ("error" in validation) {
        return NextResponse.json({ error: validation.error }, { status: 400 });
    }

    const { email, password, name } = validation.value;

    const database = new db();

    const existingUser = await database.findUserByEmail(email);
    if (existingUser) {
        if (existingUser.account_type !== "b2c" || existingUser.email_verified_at !== null) {
            return NextResponse.json({ status: "already_verified" satisfies RegistrationStatus });
        }

        const expiresAt = existingUser.email_verification_expires_at instanceof Date
            ? existingUser.email_verification_expires_at
            : new Date(existingUser.email_verification_expires_at ?? 0);
        const verificationExpired = Number.isNaN(expiresAt.getTime()) || expiresAt.getTime() <= Date.now();

        if (!verificationExpired) {
            return NextResponse.json({ status: "verification_pending" satisfies RegistrationStatus });
        }

        const replacementToken = crypto.randomBytes(32).toString("hex");
        const renewed = await database.renewEmailVerificationToken(existingUser.user_id, replacementToken);

        if (!renewed) {
            return NextResponse.json({ status: "verification_pending" satisfies RegistrationStatus });
        }

        return sendVerificationEmail(req, email, existingUser.name, replacementToken, "verification_resent");
    }

    const hashed = await bcrypt.hash(password, 10);
    const emailVerificationToken = crypto.randomBytes(32).toString("hex");

    const newUser: User = {
        user_id: uuidv4(),
        login: email,
        name,
        password_hash: hashed,
        account_type: "b2c",
        email_verification_token: emailVerificationToken,
    };

    try {

    await database.createB2cUserWithRequestRecord(newUser);
    } catch (error) {
        if (isDuplicateKeyError(error)) {
            return NextResponse.json({ error: "Пользователь с таким адресом уже существует" }, { status: 400 });
        }
        throw error;
    }

    return sendVerificationEmail(req, email, name, emailVerificationToken, "verification_sent");
}

    async function sendVerificationEmail(
    req: Request,
    email: string,
    name: string,
    token: string,
    status: "verification_resent" | "verification_sent"
) {
    const verificationUrl = `${getPublicBaseUrl(req)}/register/verify?token=${token}`;

    try {
        await sendMail(
            email,
            "Подтверждение регистрации EasyMed",
            buildVerificationEmail(name, verificationUrl)
        );
        return NextResponse.json({ status });
    } catch {
        return NextResponse.json(
            { error: "Не удалось отправить письмо. Проверьте настройки почты на сервере и повторите регистрацию." },
            { status: 502 }
        );
    }
}
