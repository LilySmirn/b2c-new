import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { Suspense } from "react";
import "./globals.css";

import AuthButtonsServer from './components/AuthButtonsServer';
// import Header from "./components/Header";
import ConditionalHeader from './components/ConditionalHeader';
import ConditionalFooter from './components/ConditionalFooter';
import NoTranslate from './components/NoTranslate';
import RouteBodyClass from './components/RouteBodyClass';
import UserBlockingGuard from './modules/userBlocking/components/UserBlockingGuard';
import landingLogo from '@/assets/images/landing/logo.svg';
import SocialLinks from './components/SocialLinks';
import MetrikaPageViews from './components/MetrikaPageViews';

export const metadata: Metadata = {
  title: "EasyMed",
  description: "EasyMed",
};

export default async function RootLayout({
   children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="ru">
            <head>
                {/* Yandex.Metrika counter */}
                <script
                    type="text/javascript"
                    dangerouslySetInnerHTML={{
                        __html: `(function(m,e,t,r,i,k,a){
m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
m[i].l=1*new Date();
for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)
})(window, document,'script','https://mc.yandex.ru/metrika/tag.js?id=113585722', 'ym');

ym(113585722, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});`,
                    }}
                />
                {/* /Yandex.Metrika counter */}
            </head>
            <body data-metrika="113585722">
            <noscript>
                    <div><img src="https://mc.yandex.ru/watch/113585722" style={{ position: "absolute", left: "-9999px" }} alt="" /></div>
                </noscript>
                <Suspense fallback={null}>
                    <MetrikaPageViews />
                </Suspense>
                <UserBlockingGuard />
                <RouteBodyClass />
                 <ConditionalHeader>
                    <header id="header" className="header-section">
                    <div className="header-container">
                        <Link href="/" className="header-logo-link notranslate" translate="no" aria-label="EasyMed — на главную">
                            <Image src={landingLogo}
                                   alt="EasyMed" width={90} height={58}
                                   priority />
                        </Link>
                        <nav aria-label="Главное меню" className="navigation">
                            <ul className="main-menu">
                                <li><Link href="/#capabilities">Возможности</Link></li>
                                <li><Link href="/#pricing">Тарифы</Link></li>
                                <li><Link href="/#reviews">Отзывы</Link></li>
                                <li><Link href="/#other-solutions">О компании</Link></li>
                                <li><Link href="/#faq">FAQ</Link></li>
                            </ul>
                        </nav>
                        <div className="header-buttons">
                            <SocialLinks className="header-socials" />
                            <AuthButtonsServer variant="header" />
                            <button type="button" className="btn btn-logout-preview">Выйти</button>
                            <Link href="/mkb" className="btn btn-back-preview">←Назад</Link>
                        </div>
                        <div className="mobile-nav">
                            <button className="burger-btn" aria-label="Открыть меню">
                                <span className="burger-line"></span>
                                <span className="burger-line"></span>
                                <span className="burger-line"></span>
                            </button>

                            <div className="mobile-menu">
                                <nav aria-label="Мобильное меню">
                                    <ul className="mobile-menu-list">
                                        <li><Link href="/#capabilities">Возможности</Link></li>
                                        <li><Link href="/#pricing">Тарифы</Link></li>
                                        <li><Link href="/#video">Видео-инструкция</Link></li>
                                        <li><Link href="/#reviews">Отзывы</Link></li>
                                        <li><Link href="/#other-solutions">О компании</Link></li>
                                        <li><Link href="/#faq">FAQ</Link></li>
                                    </ul>
                                </nav>
                                <div className="mobile-buttons">
                                    <Link href="/login" className="btn btn-login btn-auth">Войти</Link>
                                </div>
                            </div>
                        </div>
                        <div className="overlay hidden"></div>
                    </div>
                </header>
                </ConditionalHeader>

                <main className="site-main">{children}</main>
                <ConditionalFooter>
                <footer id="footer" className="footer">
                    <div className="footer-container">
                        <section className="footer-contacts" id="contact" aria-labelledby="footer-contacts-heading">
                            <h2 id="footer-contacts-heading" className="visually-hidden">Контакты</h2>
                            <ul className="footer-contact-list">
                                <li><strong>Email: </strong><Link href="mailto:info@easymed.pro">info@easymed.pro</Link></li>
                            </ul>
                            <SocialLinks className="footer-socials" />
                            <hr />
                        </section>

                        <section className="footer-legal" aria-labelledby="footer-legal-heading">
                            <h2 id="footer-legal-heading" className="visually-hidden">Правовая информация</h2>
                            <div className="legal-link">
                                <a href="/policy.pdf" target="_blank" rel="noopener noreferrer">
                                    Политика конфиденциальности
                                </a>
                                <a href="/agreement.pdf" target="_blank" rel="noopener noreferrer">
                                    Пользовательское соглашение
                                </a>
                            </div>
                            <div className="copyright">
                              2026 <NoTranslate>easymed.pro</NoTranslate>
                            </div>
                            <div className="inn">
                                ИП Васильцов Давыд Юрьевич  <br />
                                ОГРНИП 324784700301501  <br />
                                ИНН 781304344630
                            </div>
                        </section>
                    </div>
                </footer>
                </ConditionalFooter>
            </body>
        </html>
    );
}
