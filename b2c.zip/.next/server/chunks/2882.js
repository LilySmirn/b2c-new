exports.id=2882,exports.ids=[2882],exports.modules={28303:a=>{function b(a){var b=Error("Cannot find module '"+a+"'");throw b.code="MODULE_NOT_FOUND",b}b.keys=()=>[],b.resolve=b,b.id=28303,a.exports=b},75920:(a,b,c)=>{"use strict";c.d(b,{OV:()=>n,k$:()=>r,Ay:()=>t,VN:()=>k,g$:()=>s,PN:()=>q,dJ:()=>p,cw:()=>m,oL:()=>o,gD:()=>i,dz:()=>g,dZ:()=>l});var d=c(29382),e=c(32524);let f=Number(process.env.DB_PORT??3306),g=d.createPool({host:process.env.DB_HOST,port:Number.isNaN(f)?3306:f,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME,waitForConnections:!0,connectionLimit:10,queueLimit:0});async function h(a,b,c,d=g){await d.query(`UPDATE payments
         SET yookassa_payment_id = ?, confirmation_url = ?, status = 'pending', updated_at = UTC_TIMESTAMP()
         WHERE payment_id = ? AND status = 'creating'`,[b,c,a]);let[e]=await d.query("SELECT status FROM payments WHERE payment_id = ? LIMIT 1",[a]),f=e[0]?.status;if(!["creating","pending","succeeded","canceled","error"].includes(f))throw Error(`Payment ${a} was not found after YooKassa creation`);return f}async function i(a,b=g){let[c]=await b.query(`SELECT 1
         FROM subscriptions
         WHERE user_id = ?
           AND expiration_date > NOW()
         LIMIT 1`,[a]);return c.length>0}async function j(a,b,c=!1){let[d]=await b.query(`SELECT current_count,
                last_request IS NOT NULL
                    AND DATE(last_request) = CURRENT_DATE()
                    AND NOT EXISTS (
                        SELECT 1
                        FROM subscriptions
                        WHERE user_id = user_requests.user_id
                          AND expiration_date <= NOW()
                          AND expiration_date >= user_requests.last_request
                    ) AS requested_in_current_demo_period_today
         FROM user_requests
         WHERE user_id = ?${c?" FOR UPDATE":""}`,[a]),e=d[0];return 1===Number(e?.requested_in_current_demo_period_today)?Number(e.current_count):0}async function k(a){let b=await i(a),c=b?0:await j(a,g);return{hasActiveSubscription:b,limit:5,used:c,remaining:b?5:Math.max(0,5-c)}}async function l(a){let b=await g.getConnection();try{if(await b.beginTransaction(),await i(a,b))return await b.query(`UPDATE user_requests
                 SET current_count = 0
                 WHERE user_id = ?`,[a]),await b.commit(),{allowed:!0,hasActiveSubscription:!0};await b.query(`INSERT IGNORE INTO user_requests (user_id, current_count, last_request, total_count)
             VALUES (?, 0, NULL, 0)`,[a]);let c=await j(a,b,!0);if(c>=5)return await b.commit(),{allowed:!1,hasActiveSubscription:!1,limit:5,used:c,remaining:0};return await b.query(`UPDATE user_requests
             SET current_count = ?,
                 total_count = total_count + 1,
                 last_request = NOW()
             WHERE user_id = ?`,[c+1,a]),await b.commit(),{allowed:!0,hasActiveSubscription:!1,limit:5,used:c+1,remaining:5-c-1}}catch(a){throw await b.rollback(),a}finally{b.release()}}async function m(a){let[b]=await g.query("SELECT price FROM tariffs WHERE tariff_id = ? LIMIT 1",[a]);return b[0]?Number(b[0].price):null}async function n(){let[a]=await g.query("SELECT 1 AS ok");return Array.isArray(a)&&a.length>0}async function o(){let[a]=await g.query("SELECT COUNT(*) AS users_count FROM users");return Number(a[0]?.users_count??0)}async function p(a){let[b]=await g.query(`SELECT p.payment_id, p.yookassa_payment_id, p.user_id, p.tariff_id, p.amount,
                p.order_number, p.status, u.login AS user_label, t.title AS tariff_title
         FROM payments p
         LEFT JOIN users u ON u.user_id = p.user_id
         LEFT JOIN tariffs t ON t.tariff_id = p.tariff_id
         WHERE p.yookassa_payment_id = ? LIMIT 1`,[a]),c=b[0];return c?{paymentId:String(c.payment_id),yookassaPaymentId:String(c.yookassa_payment_id),userId:String(c.user_id),tariffId:String(c.tariff_id),amount:String(c.amount),orderNumber:null==c.order_number?null:String(c.order_number),status:String(c.status),userLabel:null==c.user_label?String(c.user_id):String(c.user_label),tariffTitle:null==c.tariff_title?null:String(c.tariff_title)}:null}async function q(a,b){let[c]=await g.query(`SELECT p.payment_id, p.yookassa_payment_id, p.user_id, p.tariff_id, p.amount,
                p.order_number, p.status, u.login AS user_label, t.title AS tariff_title
         FROM payments p
         LEFT JOIN users u ON u.user_id = p.user_id
         LEFT JOIN tariffs t ON t.tariff_id = p.tariff_id
         WHERE p.payment_id = ?
           AND p.user_id = ?
           AND p.yookassa_payment_id IS NOT NULL
         LIMIT 1`,[b,a]),d=c[0];return d?{paymentId:String(d.payment_id),yookassaPaymentId:String(d.yookassa_payment_id),userId:String(d.user_id),tariffId:String(d.tariff_id),amount:String(d.amount),orderNumber:null==d.order_number?null:String(d.order_number),status:String(d.status),userLabel:null==d.user_label?String(d.user_id):String(d.user_label),tariffTitle:null==d.tariff_title?null:String(d.tariff_title)}:null}async function r(a,b,c){let[d]=await g.execute(`UPDATE payments
         SET last_checked_at = UTC_TIMESTAMP()
         WHERE payment_id = ?
           AND user_id = ?
           AND status IN ('creating', 'pending')
           AND yookassa_payment_id IS NOT NULL
           AND (
               last_checked_at IS NULL
               OR last_checked_at <= DATE_SUB(UTC_TIMESTAMP(), INTERVAL ? SECOND)
           )`,[b,a,c]);return 1===d.affectedRows}async function s(a){let[b]=await g.query(`SELECT expiration_date FROM subscriptions
         WHERE user_id = ? ORDER BY expiration_date DESC LIMIT 1`,[a]);return b[0]?.expiration_date??null}class t{static{this.emailVerificationColumnsReady=!1}async ensureEmailVerificationColumns(){if(t.emailVerificationColumnsReady)return;let[a]=await g.query(`SELECT column_name
             FROM information_schema.columns
             WHERE table_schema = DATABASE()
               AND table_name = 'users'
               AND column_name IN (
                   'email_verified_at',
                   'email_verification_token',
                   'email_verification_expires_at'
               )`),b=new Set(a.map(a=>String(a.column_name)));b.has("email_verified_at")||await g.query("ALTER TABLE users ADD COLUMN email_verified_at datetime NULL"),b.has("email_verification_token")||await g.query("ALTER TABLE users ADD COLUMN email_verification_token varchar(64) NULL"),b.has("email_verification_expires_at")||await g.query("ALTER TABLE users ADD COLUMN email_verification_expires_at datetime NULL");let[c]=await g.query(`SELECT 1
             FROM information_schema.statistics
             WHERE table_schema = DATABASE()
               AND table_name = 'users'
               AND index_name = 'users_email_verification_token_unique'
             LIMIT 1`);0===c.length&&await g.query(`ALTER TABLE users
                 ADD UNIQUE KEY users_email_verification_token_unique (email_verification_token)`),await g.query(`
            UPDATE users
            SET email_verified_at = registration_date
            WHERE email_verified_at IS NULL
              AND email_verification_token IS NULL
              AND email_verification_expires_at IS NULL
        `),t.emailVerificationColumnsReady=!0}async getSubscriptionExpirationReminder(a){let[b]=await g.query(`SELECT
                s.id AS subscription_id,
                s.expiration_date,
                t.title AS tariff_title
             FROM subscriptions s
             INNER JOIN tariffs t ON t.tariff_id = s.last_paid_tariff_id
             LEFT JOIN payments p
                ON p.user_id = s.user_id
               AND p.tariff_id = s.last_paid_tariff_id
             WHERE s.user_id = ?
               AND s.id = (
                   SELECT newest.id
                   FROM subscriptions newest
                   WHERE newest.user_id = s.user_id
                   ORDER BY newest.expiration_date DESC
                   LIMIT 1
               )
               AND s.is_auto_renewal = 0
               AND s.expiration_date >= NOW()
               AND s.expiration_date <= DATE_ADD(NOW(), INTERVAL 4 DAY)
             GROUP BY s.id, s.expiration_date, t.title
             ORDER BY s.expiration_date DESC
             LIMIT 1`,[a]),c=b[0];return c?{subscriptionId:String(c.subscription_id),expirationDate:c.expiration_date instanceof Date?c.expiration_date:new Date(c.expiration_date),tariffTitle:c.tariff_title}:null}async hasActiveB2cSession(a,b){let[c]=await g.query(`SELECT session_id, user_id
             FROM user_sessions
             WHERE session_id = ?
               AND user_id = ?
               AND revoked_at IS NULL
               AND expires_at > NOW()
             LIMIT 1`,[a,b]);return c.length>0}async getCurrentUser(a){let[b]=await g.query("SELECT user_id, login, name FROM users WHERE user_id = ?",[a]);return b[0]??null}async getCurrentPayment(a){let[b]=await g.query(`SELECT
                p.payment_id,
                p.tariff_id,
                p.status,
                p.cancellation_reason,
                p.confirmation_url,
                t.title AS tariff_name
             FROM payments p
             INNER JOIN tariffs t ON t.tariff_id = p.tariff_id
             WHERE p.user_id = ?
               AND (
                   p.status = 'pending'
                   OR (
                       p.status = 'canceled'
                       AND p.canceled_at >= CONVERT_TZ(
                           DATE(CONVERT_TZ(UTC_TIMESTAMP(), '+00:00', '+03:00')),
                           '+03:00', '+00:00'
                       )
                       AND p.canceled_at < DATE_ADD(
                           CONVERT_TZ(
                               DATE(CONVERT_TZ(UTC_TIMESTAMP(), '+00:00', '+03:00')),
                               '+03:00', '+00:00'
                           ),
                           INTERVAL 1 DAY
                       )
                   )
               )
             ORDER BY
                CASE WHEN p.status = 'pending' THEN 0 ELSE 1 END,
                p.created_at DESC,
                p.payment_id DESC
             LIMIT 1`,[a]),c=b[0];return c?{paymentId:String(c.payment_id),tariffId:String(c.tariff_id),tariffName:c.tariff_name,status:c.status,cancellationReason:c.cancellation_reason,confirmationUrl:c.confirmation_url}:null}async getPaymentStatus(a,b){let[c]=await g.query(`SELECT
                p.payment_id,
                p.tariff_id,
                p.status,
                p.cancellation_reason,
                p.confirmation_url,
                t.title AS tariff_name
             FROM payments p
             INNER JOIN tariffs t ON t.tariff_id = p.tariff_id
             WHERE p.payment_id = ?
               AND p.user_id = ?
             LIMIT 1`,[b,a]),d=c[0];return d?{paymentId:String(d.payment_id),tariffId:String(d.tariff_id),tariffName:d.tariff_name,status:d.status,cancellationReason:d.cancellation_reason,confirmationUrl:d.confirmation_url}:null}async createPendingPayment(a,b,c){let d=await g.getConnection();try{await d.beginTransaction();let[f]=await d.query("SELECT user_id, login FROM users WHERE user_id = ? FOR UPDATE",[a]),g=String(f[0].login),[h]=await d.query(`SELECT
                    p.payment_id,
                    p.tariff_id,
                    p.amount,
                    p.status,
                    p.confirmation_url,
                    DATE_ADD(p.created_at, INTERVAL 30 SECOND) AS retry_allowed_at,
                    t.title AS tariff_name
                 FROM payments p
                 INNER JOIN tariffs t ON t.tariff_id = p.tariff_id
                 WHERE p.user_id = ?
                   AND p.status IN ('creating', 'pending')
                   AND p.created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 SECOND)
                 ORDER BY p.created_at DESC, p.payment_id DESC
                 LIMIT 1`,[a]),i=h[0];if(i)return await d.commit(),{outcome:"already_pending",payment:{paymentId:String(i.payment_id),tariffId:String(i.tariff_id),tariffName:i.tariff_name,amount:Number(i.amount),status:i.status,retryAllowedAt:new Date(i.retry_allowed_at).toISOString(),confirmationUrl:i.confirmation_url}};let[j]=await d.query("SELECT tariff_id, title, price FROM tariffs WHERE tariff_id = ? LIMIT 1",[b]),k=j[0];if(!k)return await d.rollback(),{outcome:"tariff_not_found"};let l=(0,e.A)(),[m]=await d.query(`SELECT next_value
                 FROM payment_order_sequence
                 WHERE sequence_name = 'payments'
                 FOR UPDATE`),n=String(m[0].next_value);return await d.query(`UPDATE payment_order_sequence
                 SET next_value = next_value + 1
                 WHERE sequence_name = 'payments'`),await d.query(`INSERT INTO payments (
                    user_id, tariff_id, amount, payment_id, status, idempotency_key, order_number,
                    created_at, updated_at
                 ) VALUES (?, ?, ?, ?, 'creating', ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())`,[a,b,k.price,c,l,n]),await d.commit(),{outcome:"created",payment:{paymentId:c,tariffId:String(k.tariff_id),tariffName:k.title,amount:Number(k.price),status:"creating",idempotencyKey:l,orderNumber:n,customerEmail:g}}}catch(a){throw await d.rollback(),a}finally{d.release()}}async markPaymentError(a){await g.query(`UPDATE payments SET status = 'error', updated_at = UTC_TIMESTAMP()
             WHERE payment_id = ? AND status = 'creating'`,[a])}async markPaymentCheckoutCreated(a,b,c){return h(a,b,c,g)}async markPaymentPending(a){await g.query(`UPDATE payments SET status = 'pending', updated_at = UTC_TIMESTAMP()
             WHERE payment_id = ? AND status = 'creating'`,[a])}async createUser(a){let b=a.user_id,c=a.login,d=a.name,e=a.password_hash;await g.query("INSERT INTO users (user_id, login, name, password_hash, account_type) VALUES (?, ?, ?, ?, ?)",[b,c,d,e,a.account_type??"b2c"])}async createB2bUser(a){await g.query(`INSERT INTO users (user_id, login, password_hash, account_type, ip)
             VALUES (?, ?, ?, 'b2b', ?)`,[a.userId,a.login,a.passwordHash,a.ip])}async createB2cUserWithRequestRecord(a){await this.ensureEmailVerificationColumns();let b=await g.getConnection();try{await b.beginTransaction(),await this.insertB2cUser(b,a),await this.insertUserRequestRecord(b,a.user_id),await b.commit()}catch(a){throw await b.rollback(),a}finally{b.release()}}async insertB2cUser(a,b){await a.query(`INSERT INTO users (
                user_id,
                login,
                name,
                password_hash,
                account_type,
                email_verified_at,
                email_verification_token,
                email_verification_expires_at
            )
            VALUES (?, ?, ?, ?, 'b2c', NULL, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))`,[b.user_id,b.login,b.name,b.password_hash,b.email_verification_token])}async insertUserRequestRecord(a,b){await a.query(`INSERT INTO user_requests (user_id, current_count, last_request, total_count)
         VALUES (?, 0, NULL, 0)`,[b])}async findUserByEmail(a){await this.ensureEmailVerificationColumns();let[b]=await g.query("SELECT * FROM users WHERE login = ?",[a]);return Array.isArray(b)&&b.length>0?b[0]:null}async findUserByLogin(a){let[b]=await g.query("SELECT * FROM users WHERE login = ? LIMIT 1",[a]);return b[0]??null}async findUserById(a){let[b]=await g.query("SELECT * FROM users WHERE user_id = ? LIMIT 1",[a]);return b[0]??null}async resetUserPassword(a,b,c,d){let e=await g.getConnection();try{await e.beginTransaction();let[f]=await e.query("UPDATE users SET password_hash = ? WHERE user_id = ? AND login = ? AND password_hash = ?",[d,a,b,c]),g="affectedRows"in f?Number(f.affectedRows):0;return 1===g&&await e.query("UPDATE user_sessions SET revoked_at = NOW() WHERE user_id = ? AND revoked_at IS NULL",[a]),await e.commit(),g}catch(a){throw await e.rollback(),a}finally{e.release()}}async renewEmailVerificationToken(a,b){await this.ensureEmailVerificationColumns();let[c]=await g.query(`UPDATE users
             SET email_verification_token = ?,
                 email_verification_expires_at = DATE_ADD(NOW(), INTERVAL 24 HOUR)
             WHERE user_id = ?
               AND account_type = 'b2c'
               AND email_verified_at IS NULL
               AND (
                   email_verification_expires_at IS NULL
                   OR email_verification_expires_at <= NOW()
               )`,[b,a]);return"affectedRows"in c&&1===Number(c.affectedRows)}async verifyUserEmail(a){await this.ensureEmailVerificationColumns();let[b]=await g.query(`SELECT user_id, email_verified_at, email_verification_expires_at
             FROM users
             WHERE email_verification_token = ?
             LIMIT 1`,[a]),c=b[0];if(!c)return"not_found";if(null!==c.email_verified_at)return"ok";let d=c.email_verification_expires_at instanceof Date?c.email_verification_expires_at:new Date(c.email_verification_expires_at??0);return Number.isNaN(d.getTime())||d.getTime()<Date.now()?"expired":(await g.query(`UPDATE users
             SET email_verified_at = NOW(),
                 email_verification_token = NULL,
                 email_verification_expires_at = NULL
             WHERE user_id = ?`,[c.user_id]),"ok")}async createB2cSessionReplacingExisting(a){let b=await g.getConnection();try{await b.beginTransaction(),await b.query(`SELECT user_id
                 FROM users
                 WHERE user_id = ?
                 FOR UPDATE`,[a.userId]),await b.query(`UPDATE user_sessions
                 SET revoked_at = NOW()
                 WHERE user_id = ?
                   AND revoked_at IS NULL`,[a.userId]),await b.query(`INSERT INTO user_sessions (
                    session_id,
                    user_id,
                    device_id,
                    device_name,
                    ip_address,
                    expires_at
                )
                VALUES (?, ?, ?, ?, ?, ?)`,[a.sessionId,a.userId,a.deviceId,a.deviceName,a.ipAddress,a.expiresAt]),await b.commit()}catch(a){throw await b.rollback(),a}finally{b.release()}}async revokeB2cSession(a,b){await g.query(`UPDATE user_sessions
             SET revoked_at = NOW()
             WHERE session_id = ?
               AND user_id = ?
               AND revoked_at IS NULL`,[a,b])}async deleteUser(a){await g.query("DELETE FROM users WHERE user_id = ?",[a])}async updateUser(a,b){let c=[],d=[];if(void 0!==b.login&&(c.push("login = ?"),d.push(b.login)),void 0!==b.name&&(c.push("name = ?"),d.push(b.name)),void 0!==b.password_hash&&(c.push("password_hash = ?"),d.push(b.password_hash)),0===c.length)return;d.push(a);let e=`UPDATE users SET ${c.join(", ")} WHERE user_id = ?`;await g.query(e,d)}async changeUserEmail(a,b,c){let[d]=await g.query(`UPDATE users
             SET login = ?
             WHERE user_id = ?
               AND login = ?`,[c,a,b]);return"affectedRows"in d?Number(d.affectedRows):0}async getUserSubscriptions(a){let[b]=await g.query("SELECT id, s.user_id, t.title, s.expiration_date, s.is_auto_renewal FROM subscriptions s JOIN tariffs t ON s.last_paid_tariff_id = t.tariff_id WHERE s.user_id = ?",[a]);if(!Array.isArray(b)||0===b.length)return null;let c=[];return b.forEach(a=>{c.push({id:a.id.toString(),user_id:a.user_id.toString(),title:a.title,expiration_date:a.expiration_date instanceof Date?a.expiration_date.toISOString():String(a.expiration_date),is_auto_renewal:!!a.is_auto_renewal})}),c}async getLatestUserSubscription(a){let[b]=await g.query(`SELECT s.id, s.user_id, t.title, t.duration, s.expiration_date, s.is_auto_renewal
             FROM subscriptions s
             INNER JOIN tariffs t ON t.tariff_id = s.last_paid_tariff_id
             WHERE s.user_id = ?
             ORDER BY s.expiration_date DESC, s.start_date DESC
             LIMIT 1`,[a]),[c]=b;return void 0===c?null:{id:String(c.id),user_id:String(c.user_id),title:c.title??"",duration:c.duration,expiration_date:c.expiration_date instanceof Date?c.expiration_date.toISOString():String(c.expiration_date),is_auto_renewal:!!c.is_auto_renewal}}async updateAutoRenewal(a,b){await g.query("UPDATE subscriptions SET is_auto_renewal = ? WHERE id = ?",[+!!b,a])}async getTariffById(a){let[b]=await g.query("SELECT duration FROM tariffs WHERE tariff_id = ?",[a]);return b[0]??null}async getSubscription(a){let[b]=await g.query("SELECT * FROM subscriptions WHERE user_id = ? AND expiration_date > CURRENT_DATE()",[a]);return b[0]??null}async getTariffDuration(a){let[b]=await g.query("SELECT duration FROM tariffs WHERE tariff_id = ?",[a]);return 0===b.length?null:b[0].duration}async addSubscription(a,b,c,d){let f=(0,e.A)();await g.query(`INSERT INTO subscriptions (id, user_id, last_paid_tariff_id, start_date, expiration_date, is_auto_renewal)
             VALUES (?, ?, ?, ?, ?, ?)`,[f,a,b,c,d,1])}async updateSubscription(a,b){await g.query("UPDATE subscriptions SET expiration_date = ? WHERE id = ?",[b,a])}async getTariffName(a){let[b]=await g.query("SELECT title FROM tariffs WHERE tariff_id = ?",[a]);return 0===b.length?null:b[0].title}async createUserRequestRecord(a){await g.query(`INSERT INTO user_requests (user_id, current_count, last_request, total_count)
         VALUES (?, 0, NULL, 0)`,[a])}async logEvent(a){let{level:b,source:c,event_name:d,message:e,stacktrace:f,user_id:h}=a;await g.query(`INSERT INTO error_logs (level, source, event_name, message, stacktrace, user_id)
             VALUES (?, ?, ?, ?, ?, ?)`,[b,c,d,e,f??null,h??null])}}}};